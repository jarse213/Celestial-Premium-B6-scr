/*
 * Decompiled with CFR 0.150.
 */
package org.yaml.snakeyaml.representer;

import org.yaml.snakeyaml.nodes.Node;

public interface Represent {
    public Node representData(Object var1);
}

