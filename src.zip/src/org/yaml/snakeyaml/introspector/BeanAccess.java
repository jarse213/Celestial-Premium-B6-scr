/*
 * Decompiled with CFR 0.150.
 */
package org.yaml.snakeyaml.introspector;

public enum BeanAccess {
    DEFAULT,
    FIELD,
    PROPERTY;

}

