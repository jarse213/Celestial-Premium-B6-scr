/*
 * Decompiled with CFR 0.150.
 */
package org.yaml.snakeyaml.external.com.google.gdata.util.common.base;

public interface Escaper {
    public String escape(String var1);

    public Appendable escape(Appendable var1);
}

