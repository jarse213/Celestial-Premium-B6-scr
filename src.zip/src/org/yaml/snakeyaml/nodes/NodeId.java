/*
 * Decompiled with CFR 0.150.
 */
package org.yaml.snakeyaml.nodes;

public enum NodeId {
    scalar,
    sequence,
    mapping,
    anchor;

}

