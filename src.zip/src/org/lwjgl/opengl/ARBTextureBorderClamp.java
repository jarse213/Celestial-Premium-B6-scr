/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ARBTextureBorderClamp {
    public static final int GL_CLAMP_TO_BORDER_ARB = 33069;

    private ARBTextureBorderClamp() {
    }
}

