/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ARBTextureRGB10_A2UI {
    public static final int GL_RGB10_A2UI = 36975;

    private ARBTextureRGB10_A2UI() {
    }
}

