/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class EXTPackedFloat {
    public static final int GL_R11F_G11F_B10F_EXT = 35898;
    public static final int GL_UNSIGNED_INT_10F_11F_11F_REV_EXT = 35899;
    public static final int GL_RGBA_SIGNED_COMPONENTS_EXT = 35900;
    public static final int WGL_TYPE_RGBA_UNSIGNED_FLOAT_EXT = 8360;
    public static final int GLX_RGBA_UNSIGNED_FLOAT_TYPE_EXT = 8369;
    public static final int GLX_RGBA_UNSIGNED_FLOAT_BIT_EXT = 8;

    private EXTPackedFloat() {
    }
}

