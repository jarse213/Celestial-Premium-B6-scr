/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ARBMapBufferAlignment {
    public static final int GL_MIN_MAP_BUFFER_ALIGNMENT = 37052;

    private ARBMapBufferAlignment() {
    }
}

