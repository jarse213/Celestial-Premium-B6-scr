/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class EXTTextureSRGBDecode {
    public static final int GL_TEXTURE_SRGB_DECODE_EXT = 35400;
    public static final int GL_DECODE_EXT = 35401;
    public static final int GL_SKIP_DECODE_EXT = 35402;

    private EXTTextureSRGBDecode() {
    }
}

