/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

final class LinuxKeycodes {
    public static final int XK_Kanji = 65313;
    public static final int XK_ISO_Left_Tab = 65056;
    public static final int XK_dead_grave = 65104;
    public static final int XK_dead_acute = 65105;
    public static final int XK_dead_circumflex = 65106;
    public static final int XK_dead_tilde = 65107;
    public static final int XK_dead_macron = 65108;
    public static final int XK_dead_breve = 65109;
    public static final int XK_dead_abovedot = 65110;
    public static final int XK_dead_diaeresis = 65111;
    public static final int XK_dead_abovering = 65112;
    public static final int XK_dead_doubleacute = 65113;
    public static final int XK_dead_caron = 65114;
    public static final int XK_dead_cedilla = 65115;
    public static final int XK_dead_ogonek = 65116;
    public static final int XK_dead_iota = 65117;
    public static final int XK_dead_voiced_sound = 65118;
    public static final int XK_dead_semivoiced_sound = 65119;
    public static final int XK_dead_belowdot = 65120;
    public static final int XK_dead_hook = 65121;
    public static final int XK_dead_horn = 65122;
    public static final int XK_BackSpace = 65288;
    public static final int XK_Tab = 65289;
    public static final int XK_Linefeed = 65290;
    public static final int XK_Clear = 65291;
    public static final int XK_Return = 65293;
    public static final int XK_Pause = 65299;
    public static final int XK_Scroll_Lock = 65300;
    public static final int XK_Sys_Req = 65301;
    public static final int XK_Escape = 65307;
    public static final int XK_Delete = 65535;
    public static final int XK_Home = 65360;
    public static final int XK_Left = 65361;
    public static final int XK_Up = 65362;
    public static final int XK_Right = 65363;
    public static final int XK_Down = 65364;
    public static final int XK_Prior = 65365;
    public static final int XK_Page_Up = 65365;
    public static final int XK_Next = 65366;
    public static final int XK_Page_Down = 65366;
    public static final int XK_End = 65367;
    public static final int XK_Begin = 65368;
    public static final int XK_Select = 65376;
    public static final int XK_Print = 65377;
    public static final int XK_Execute = 65378;
    public static final int XK_Insert = 65379;
    public static final int XK_Undo = 65381;
    public static final int XK_Redo = 65382;
    public static final int XK_Menu = 65383;
    public static final int XK_Find = 65384;
    public static final int XK_Cancel = 65385;
    public static final int XK_Help = 65386;
    public static final int XK_Break = 65387;
    public static final int XK_Mode_switch = 65406;
    public static final int XK_script_switch = 65406;
    public static final int XK_Num_Lock = 65407;
    public static final int XK_KP_Space = 65408;
    public static final int XK_KP_Tab = 65417;
    public static final int XK_KP_Enter = 65421;
    public static final int XK_KP_F1 = 65425;
    public static final int XK_KP_F2 = 65426;
    public static final int XK_KP_F3 = 65427;
    public static final int XK_KP_F4 = 65428;
    public static final int XK_KP_Home = 65429;
    public static final int XK_KP_Left = 65430;
    public static final int XK_KP_Up = 65431;
    public static final int XK_KP_Right = 65432;
    public static final int XK_KP_Down = 65433;
    public static final int XK_KP_Prior = 65434;
    public static final int XK_KP_Page_Up = 65434;
    public static final int XK_KP_Next = 65435;
    public static final int XK_KP_Page_Down = 65435;
    public static final int XK_KP_End = 65436;
    public static final int XK_KP_Begin = 65437;
    public static final int XK_KP_Insert = 65438;
    public static final int XK_KP_Delete = 65439;
    public static final int XK_KP_Equal = 65469;
    public static final int XK_KP_Multiply = 65450;
    public static final int XK_KP_Add = 65451;
    public static final int XK_KP_Separator = 65452;
    public static final int XK_KP_Subtract = 65453;
    public static final int XK_KP_Decimal = 65454;
    public static final int XK_KP_Divide = 65455;
    public static final int XK_KP_0 = 65456;
    public static final int XK_KP_1 = 65457;
    public static final int XK_KP_2 = 65458;
    public static final int XK_KP_3 = 65459;
    public static final int XK_KP_4 = 65460;
    public static final int XK_KP_5 = 65461;
    public static final int XK_KP_6 = 65462;
    public static final int XK_KP_7 = 65463;
    public static final int XK_KP_8 = 65464;
    public static final int XK_KP_9 = 65465;
    public static final int XK_F1 = 65470;
    public static final int XK_F2 = 65471;
    public static final int XK_F3 = 65472;
    public static final int XK_F4 = 65473;
    public static final int XK_F5 = 65474;
    public static final int XK_F6 = 65475;
    public static final int XK_F7 = 65476;
    public static final int XK_F8 = 65477;
    public static final int XK_F9 = 65478;
    public static final int XK_F10 = 65479;
    public static final int XK_F11 = 65480;
    public static final int XK_L1 = 65480;
    public static final int XK_F12 = 65481;
    public static final int XK_L2 = 65481;
    public static final int XK_F13 = 65482;
    public static final int XK_L3 = 65482;
    public static final int XK_F14 = 65483;
    public static final int XK_L4 = 65483;
    public static final int XK_F15 = 65484;
    public static final int XK_L5 = 65484;
    public static final int XK_F16 = 65485;
    public static final int XK_L6 = 65485;
    public static final int XK_F17 = 65486;
    public static final int XK_L7 = 65486;
    public static final int XK_F18 = 65487;
    public static final int XK_L8 = 65487;
    public static final int XK_F19 = 65488;
    public static final int XK_L9 = 65488;
    public static final int XK_F20 = 65489;
    public static final int XK_L10 = 65489;
    public static final int XK_F21 = 65490;
    public static final int XK_R1 = 65490;
    public static final int XK_F22 = 65491;
    public static final int XK_R2 = 65491;
    public static final int XK_F23 = 65492;
    public static final int XK_R3 = 65492;
    public static final int XK_F24 = 65493;
    public static final int XK_R4 = 65493;
    public static final int XK_F25 = 65494;
    public static final int XK_R5 = 65494;
    public static final int XK_F26 = 65495;
    public static final int XK_R6 = 65495;
    public static final int XK_F27 = 65496;
    public static final int XK_R7 = 65496;
    public static final int XK_F28 = 65497;
    public static final int XK_R8 = 65497;
    public static final int XK_F29 = 65498;
    public static final int XK_R9 = 65498;
    public static final int XK_F30 = 65499;
    public static final int XK_R10 = 65499;
    public static final int XK_F31 = 65500;
    public static final int XK_R11 = 65500;
    public static final int XK_F32 = 65501;
    public static final int XK_R12 = 65501;
    public static final int XK_F33 = 65502;
    public static final int XK_R13 = 65502;
    public static final int XK_F34 = 65503;
    public static final int XK_R14 = 65503;
    public static final int XK_F35 = 65504;
    public static final int XK_R15 = 65504;
    public static final int XK_Shift_L = 65505;
    public static final int XK_Shift_R = 65506;
    public static final int XK_Control_L = 65507;
    public static final int XK_Control_R = 65508;
    public static final int XK_Caps_Lock = 65509;
    public static final int XK_Shift_Lock = 65510;
    public static final int XK_Meta_L = 65511;
    public static final int XK_Meta_R = 65512;
    public static final int XK_Alt_L = 65513;
    public static final int XK_Alt_R = 65514;
    public static final int XK_Super_L = 65515;
    public static final int XK_Super_R = 65516;
    public static final int XK_Hyper_L = 65517;
    public static final int XK_Hyper_R = 65518;
    public static final int XK_space = 32;
    public static final int XK_exclam = 33;
    public static final int XK_quotedbl = 34;
    public static final int XK_numbersign = 35;
    public static final int XK_dollar = 36;
    public static final int XK_percent = 37;
    public static final int XK_ampersand = 38;
    public static final int XK_apostrophe = 39;
    public static final int XK_quoteright = 39;
    public static final int XK_parenleft = 40;
    public static final int XK_parenright = 41;
    public static final int XK_asterisk = 42;
    public static final int XK_plus = 43;
    public static final int XK_comma = 44;
    public static final int XK_minus = 45;
    public static final int XK_period = 46;
    public static final int XK_slash = 47;
    public static final int XK_0 = 48;
    public static final int XK_1 = 49;
    public static final int XK_2 = 50;
    public static final int XK_3 = 51;
    public static final int XK_4 = 52;
    public static final int XK_5 = 53;
    public static final int XK_6 = 54;
    public static final int XK_7 = 55;
    public static final int XK_8 = 56;
    public static final int XK_9 = 57;
    public static final int XK_colon = 58;
    public static final int XK_semicolon = 59;
    public static final int XK_less = 60;
    public static final int XK_equal = 61;
    public static final int XK_greater = 62;
    public static final int XK_question = 63;
    public static final int XK_at = 64;
    public static final int XK_A = 65;
    public static final int XK_B = 66;
    public static final int XK_C = 67;
    public static final int XK_D = 68;
    public static final int XK_E = 69;
    public static final int XK_F = 70;
    public static final int XK_G = 71;
    public static final int XK_H = 72;
    public static final int XK_I = 73;
    public static final int XK_J = 74;
    public static final int XK_K = 75;
    public static final int XK_L = 76;
    public static final int XK_M = 77;
    public static final int XK_N = 78;
    public static final int XK_O = 79;
    public static final int XK_P = 80;
    public static final int XK_Q = 81;
    public static final int XK_R = 82;
    public static final int XK_S = 83;
    public static final int XK_T = 84;
    public static final int XK_U = 85;
    public static final int XK_V = 86;
    public static final int XK_W = 87;
    public static final int XK_X = 88;
    public static final int XK_Y = 89;
    public static final int XK_Z = 90;
    public static final int XK_bracketleft = 91;
    public static final int XK_backslash = 92;
    public static final int XK_bracketright = 93;
    public static final int XK_asciicircum = 94;
    public static final int XK_underscore = 95;
    public static final int XK_grave = 96;
    public static final int XK_quoteleft = 96;
    public static final int XK_a = 97;
    public static final int XK_b = 98;
    public static final int XK_c = 99;
    public static final int XK_d = 100;
    public static final int XK_e = 101;
    public static final int XK_f = 102;
    public static final int XK_g = 103;
    public static final int XK_h = 104;
    public static final int XK_i = 105;
    public static final int XK_j = 106;
    public static final int XK_k = 107;
    public static final int XK_l = 108;
    public static final int XK_m = 109;
    public static final int XK_n = 110;
    public static final int XK_o = 111;
    public static final int XK_p = 112;
    public static final int XK_q = 113;
    public static final int XK_r = 114;
    public static final int XK_s = 115;
    public static final int XK_t = 116;
    public static final int XK_u = 117;
    public static final int XK_v = 118;
    public static final int XK_w = 119;
    public static final int XK_x = 120;
    public static final int XK_y = 121;
    public static final int XK_z = 122;
    public static final int XK_braceleft = 123;
    public static final int XK_bar = 124;
    public static final int XK_braceright = 125;
    public static final int XK_asciitilde = 126;
    public static final int XK_nobreakspace = 160;
    public static final int XK_exclamdown = 161;
    public static final int XK_cent = 162;
    public static final int XK_sterling = 163;
    public static final int XK_currency = 164;
    public static final int XK_yen = 165;
    public static final int XK_brokenbar = 166;
    public static final int XK_section = 167;
    public static final int XK_diaeresis = 168;
    public static final int XK_copyright = 169;
    public static final int XK_ordfeminine = 170;
    public static final int XK_guillemotleft = 171;
    public static final int XK_notsign = 172;
    public static final int XK_hyphen = 173;
    public static final int XK_registered = 174;
    public static final int XK_macron = 175;
    public static final int XK_degree = 176;
    public static final int XK_plusminus = 177;
    public static final int XK_twosuperior = 178;
    public static final int XK_threesuperior = 179;
    public static final int XK_acute = 180;
    public static final int XK_mu = 181;
    public static final int XK_paragraph = 182;
    public static final int XK_periodcentered = 183;
    public static final int XK_cedilla = 184;
    public static final int XK_onesuperior = 185;
    public static final int XK_masculine = 186;
    public static final int XK_guillemotright = 187;
    public static final int XK_onequarter = 188;
    public static final int XK_onehalf = 189;
    public static final int XK_threequarters = 190;
    public static final int XK_questiondown = 191;
    public static final int XK_Agrave = 192;
    public static final int XK_Aacute = 193;
    public static final int XK_Acircumflex = 194;
    public static final int XK_Atilde = 195;
    public static final int XK_Adiaeresis = 196;
    public static final int XK_Aring = 197;
    public static final int XK_AE = 198;
    public static final int XK_Ccedilla = 199;
    public static final int XK_Egrave = 200;
    public static final int XK_Eacute = 201;
    public static final int XK_Ecircumflex = 202;
    public static final int XK_Ediaeresis = 203;
    public static final int XK_Igrave = 204;
    public static final int XK_Iacute = 205;
    public static final int XK_Icircumflex = 206;
    public static final int XK_Idiaeresis = 207;
    public static final int XK_ETH = 208;
    public static final int XK_Eth = 208;
    public static final int XK_Ntilde = 209;
    public static final int XK_Ograve = 210;
    public static final int XK_Oacute = 211;
    public static final int XK_Ocircumflex = 212;
    public static final int XK_Otilde = 213;
    public static final int XK_Odiaeresis = 214;
    public static final int XK_multiply = 215;
    public static final int XK_Oslash = 216;
    public static final int XK_Ooblique = 216;
    public static final int XK_Ugrave = 217;
    public static final int XK_Uacute = 218;
    public static final int XK_Ucircumflex = 219;
    public static final int XK_Udiaeresis = 220;
    public static final int XK_Yacute = 221;
    public static final int XK_THORN = 222;
    public static final int XK_Thorn = 222;
    public static final int XK_ssharp = 223;
    public static final int XK_agrave = 224;
    public static final int XK_aacute = 225;
    public static final int XK_acircumflex = 226;
    public static final int XK_atilde = 227;
    public static final int XK_adiaeresis = 228;
    public static final int XK_aring = 229;
    public static final int XK_ae = 230;
    public static final int XK_ccedilla = 231;
    public static final int XK_egrave = 232;
    public static final int XK_eacute = 233;
    public static final int XK_ecircumflex = 234;
    public static final int XK_ediaeresis = 235;
    public static final int XK_igrave = 236;
    public static final int XK_iacute = 237;
    public static final int XK_icircumflex = 238;
    public static final int XK_idiaeresis = 239;
    public static final int XK_eth = 240;
    public static final int XK_ntilde = 241;
    public static final int XK_ograve = 242;
    public static final int XK_oacute = 243;
    public static final int XK_ocircumflex = 244;
    public static final int XK_otilde = 245;
    public static final int XK_odiaeresis = 246;
    public static final int XK_division = 247;
    public static final int XK_oslash = 248;
    public static final int XK_ooblique = 248;
    public static final int XK_ugrave = 249;
    public static final int XK_uacute = 250;
    public static final int XK_ucircumflex = 251;
    public static final int XK_udiaeresis = 252;
    public static final int XK_yacute = 253;
    public static final int XK_thorn = 254;
    public static final int XK_ydiaeresis = 255;
    public static final int XK_ISO_Level3_Shift = 65027;

    LinuxKeycodes() {
    }

    public static int mapKeySymToLWJGLKeyCode(long keysym) {
        switch ((int)keysym) {
            case 65288: {
                return 14;
            }
            case 65056: 
            case 65289: {
                return 15;
            }
            case 65293: {
                return 28;
            }
            case 65299: {
                return 197;
            }
            case 65300: {
                return 70;
            }
            case 65301: {
                return 183;
            }
            case 65307: {
                return 1;
            }
            case 65535: {
                return 211;
            }
            case 65313: {
                return 148;
            }
            case 65360: {
                return 199;
            }
            case 65361: {
                return 203;
            }
            case 65362: {
                return 200;
            }
            case 65363: {
                return 205;
            }
            case 65364: {
                return 208;
            }
            case 65365: {
                return 201;
            }
            case 65366: {
                return 209;
            }
            case 65367: {
                return 207;
            }
            case 65387: {
                return 197;
            }
            case 65379: {
                return 210;
            }
            case 65407: {
                return 69;
            }
            case 65408: {
                return 57;
            }
            case 65417: {
                return 15;
            }
            case 65421: {
                return 156;
            }
            case 65425: {
                return 59;
            }
            case 65426: {
                return 60;
            }
            case 65427: {
                return 61;
            }
            case 65428: {
                return 62;
            }
            case 65429: {
                return 199;
            }
            case 65430: {
                return 203;
            }
            case 65431: {
                return 200;
            }
            case 65432: {
                return 205;
            }
            case 65433: {
                return 208;
            }
            case 65434: {
                return 201;
            }
            case 65435: {
                return 209;
            }
            case 65436: {
                return 207;
            }
            case 65438: {
                return 210;
            }
            case 65439: {
                return 211;
            }
            case 65469: {
                return 141;
            }
            case 65450: {
                return 55;
            }
            case 65451: {
                return 78;
            }
            case 65453: {
                return 74;
            }
            case 65454: {
                return 83;
            }
            case 65455: {
                return 181;
            }
            case 65456: {
                return 82;
            }
            case 65457: {
                return 79;
            }
            case 65458: {
                return 80;
            }
            case 65459: {
                return 81;
            }
            case 65460: {
                return 75;
            }
            case 65461: {
                return 76;
            }
            case 65462: {
                return 77;
            }
            case 65463: {
                return 71;
            }
            case 65464: {
                return 72;
            }
            case 65465: {
                return 73;
            }
            case 65470: {
                return 59;
            }
            case 65471: {
                return 60;
            }
            case 65472: {
                return 61;
            }
            case 65473: {
                return 62;
            }
            case 65474: {
                return 63;
            }
            case 65475: {
                return 64;
            }
            case 65476: {
                return 65;
            }
            case 65477: {
                return 66;
            }
            case 65478: {
                return 67;
            }
            case 65479: {
                return 68;
            }
            case 65480: {
                return 87;
            }
            case 65481: {
                return 88;
            }
            case 65482: {
                return 100;
            }
            case 65483: {
                return 101;
            }
            case 65484: {
                return 102;
            }
            case 65505: {
                return 42;
            }
            case 65506: {
                return 54;
            }
            case 65507: {
                return 29;
            }
            case 65508: {
                return 157;
            }
            case 65509: {
                return 58;
            }
            case 65511: {
                return 56;
            }
            case 65027: 
            case 65512: {
                return 184;
            }
            case 65513: {
                return 56;
            }
            case 65514: {
                return 184;
            }
            case 65104: {
                return 41;
            }
            case 65106: {
                return 144;
            }
            case 32: {
                return 57;
            }
            case 39: {
                return 40;
            }
            case 44: {
                return 51;
            }
            case 45: {
                return 12;
            }
            case 46: {
                return 52;
            }
            case 47: {
                return 53;
            }
            case 48: {
                return 11;
            }
            case 49: {
                return 2;
            }
            case 50: {
                return 3;
            }
            case 51: {
                return 4;
            }
            case 52: {
                return 5;
            }
            case 53: {
                return 6;
            }
            case 54: {
                return 7;
            }
            case 55: {
                return 8;
            }
            case 56: {
                return 9;
            }
            case 57: {
                return 10;
            }
            case 58: {
                return 146;
            }
            case 59: {
                return 39;
            }
            case 61: {
                return 13;
            }
            case 64: {
                return 145;
            }
            case 91: {
                return 26;
            }
            case 93: {
                return 27;
            }
            case 94: {
                return 144;
            }
            case 95: {
                return 147;
            }
            case 96: {
                return 41;
            }
            case 65: 
            case 97: {
                return 30;
            }
            case 66: 
            case 98: {
                return 48;
            }
            case 67: 
            case 99: {
                return 46;
            }
            case 68: 
            case 100: {
                return 32;
            }
            case 69: 
            case 101: {
                return 18;
            }
            case 70: 
            case 102: {
                return 33;
            }
            case 71: 
            case 103: {
                return 34;
            }
            case 72: 
            case 104: {
                return 35;
            }
            case 73: 
            case 105: {
                return 23;
            }
            case 74: 
            case 106: {
                return 36;
            }
            case 75: 
            case 107: {
                return 37;
            }
            case 76: 
            case 108: {
                return 38;
            }
            case 77: 
            case 109: {
                return 50;
            }
            case 78: 
            case 110: {
                return 49;
            }
            case 79: 
            case 111: {
                return 24;
            }
            case 80: 
            case 112: {
                return 25;
            }
            case 81: 
            case 113: {
                return 16;
            }
            case 82: 
            case 114: {
                return 19;
            }
            case 83: 
            case 115: {
                return 31;
            }
            case 84: 
            case 116: {
                return 20;
            }
            case 85: 
            case 117: {
                return 22;
            }
            case 86: 
            case 118: {
                return 47;
            }
            case 87: 
            case 119: {
                return 17;
            }
            case 88: 
            case 120: {
                return 45;
            }
            case 89: 
            case 121: {
                return 21;
            }
            case 90: 
            case 122: {
                return 44;
            }
        }
        return 0;
    }
}

