/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class AMDBlendMinmaxFactor {
    public static final int GL_FACTOR_MIN_AMD = 36892;
    public static final int GL_FACTOR_MAX_AMD = 36893;

    private AMDBlendMinmaxFactor() {
    }
}

