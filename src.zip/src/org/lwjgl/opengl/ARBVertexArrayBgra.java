/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ARBVertexArrayBgra {
    public static final int GL_BGRA = 32993;

    private ARBVertexArrayBgra() {
    }
}

