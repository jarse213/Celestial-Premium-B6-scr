/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

import org.lwjgl.PointerWrapperAbstract;

public final class GLSync
extends PointerWrapperAbstract {
    GLSync(long sync) {
        super(sync);
    }
}

