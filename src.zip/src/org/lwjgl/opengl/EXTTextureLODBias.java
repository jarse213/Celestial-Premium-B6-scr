/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class EXTTextureLODBias {
    public static final int GL_TEXTURE_FILTER_CONTROL_EXT = 34048;
    public static final int GL_TEXTURE_LOD_BIAS_EXT = 34049;
    public static final int GL_MAX_TEXTURE_LOD_BIAS_EXT = 34045;

    private EXTTextureLODBias() {
    }
}

