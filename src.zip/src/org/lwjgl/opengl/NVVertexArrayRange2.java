/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class NVVertexArrayRange2 {
    public static final int GL_VERTEX_ARRAY_RANGE_WITHOUT_FLUSH_NV = 34099;

    private NVVertexArrayRange2() {
    }
}

