/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ARBExplicitUniformLocation {
    public static final int GL_MAX_UNIFORM_LOCATIONS = 33390;

    private ARBExplicitUniformLocation() {
    }
}

