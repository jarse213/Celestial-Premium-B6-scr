/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class NVMultisampleFilterHint {
    public static final int GL_MULTISAMPLE_FILTER_HINT_NV = 34100;

    private NVMultisampleFilterHint() {
    }
}

