/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

import org.lwjgl.opengl.ARBBufferObject;

public final class EXTPixelBufferObject
extends ARBBufferObject {
    public static final int GL_PIXEL_PACK_BUFFER_EXT = 35051;
    public static final int GL_PIXEL_UNPACK_BUFFER_EXT = 35052;
    public static final int GL_PIXEL_PACK_BUFFER_BINDING_EXT = 35053;
    public static final int GL_PIXEL_UNPACK_BUFFER_BINDING_EXT = 35055;

    private EXTPixelBufferObject() {
    }
}

