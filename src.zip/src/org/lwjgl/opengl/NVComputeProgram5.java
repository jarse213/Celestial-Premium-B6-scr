/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class NVComputeProgram5 {
    public static final int GL_COMPUTE_PROGRAM_NV = 37115;
    public static final int GL_COMPUTE_PROGRAM_PARAMETER_BUFFER_NV = 37116;

    private NVComputeProgram5() {
    }
}

