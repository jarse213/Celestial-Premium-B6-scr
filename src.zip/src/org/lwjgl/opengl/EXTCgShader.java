/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class EXTCgShader {
    public static final int GL_CG_VERTEX_SHADER_EXT = 35086;
    public static final int GL_CG_FRAGMENT_SHADER_EXT = 35087;

    private EXTCgShader() {
    }
}

