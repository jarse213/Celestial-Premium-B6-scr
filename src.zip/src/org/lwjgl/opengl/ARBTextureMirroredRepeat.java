/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ARBTextureMirroredRepeat {
    public static final int GL_MIRRORED_REPEAT_ARB = 33648;

    private ARBTextureMirroredRepeat() {
    }
}

