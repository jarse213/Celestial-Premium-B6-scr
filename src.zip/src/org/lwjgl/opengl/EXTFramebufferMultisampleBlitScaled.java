/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class EXTFramebufferMultisampleBlitScaled {
    public static final int GL_SCALED_RESOLVE_FASTEST_EXT = 37050;
    public static final int GL_SCALED_RESOLVE_NICEST_EXT = 37051;

    private EXTFramebufferMultisampleBlitScaled() {
    }
}

