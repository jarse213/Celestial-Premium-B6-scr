/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ARBFragmentShader {
    public static final int GL_FRAGMENT_SHADER_ARB = 35632;
    public static final int GL_MAX_FRAGMENT_UNIFORM_COMPONENTS_ARB = 35657;
    public static final int GL_MAX_TEXTURE_COORDS_ARB = 34929;
    public static final int GL_MAX_TEXTURE_IMAGE_UNITS_ARB = 34930;
    public static final int GL_FRAGMENT_SHADER_DERIVATIVE_HINT_ARB = 35723;

    private ARBFragmentShader() {
    }
}

