/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class EXTBlendSubtract {
    public static final int GL_FUNC_SUBTRACT_EXT = 32778;
    public static final int GL_FUNC_REVERSE_SUBTRACT_EXT = 32779;

    private EXTBlendSubtract() {
    }
}

