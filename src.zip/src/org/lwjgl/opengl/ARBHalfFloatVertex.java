/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ARBHalfFloatVertex {
    public static final int GL_HALF_FLOAT = 5131;

    private ARBHalfFloatVertex() {
    }
}

