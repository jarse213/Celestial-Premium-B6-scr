/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class HPOcclusionTest {
    public static final int GL_OCCLUSION_TEST_HP = 33125;
    public static final int GL_OCCLUSION_TEST_RESULT_HP = 33126;

    private HPOcclusionTest() {
    }
}

