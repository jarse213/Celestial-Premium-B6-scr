/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ARBConditionalRenderInverted {
    public static final int GL_QUERY_WAIT_INVERTED = 36375;
    public static final int GL_QUERY_NO_WAIT_INVERTED = 36376;
    public static final int GL_QUERY_BY_REGION_WAIT_INVERTED = 36377;
    public static final int GL_QUERY_BY_REGION_NO_WAIT_INVERTED = 36378;

    private ARBConditionalRenderInverted() {
    }
}

