/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ARBTransformFeedbackOverflowQuery {
    public static final int GL_TRANSFORM_FEEDBACK_OVERFLOW_ARB = 33516;
    public static final int GL_TRANSFORM_FEEDBACK_STREAM_OVERFLOW_ARB = 33517;

    private ARBTransformFeedbackOverflowQuery() {
    }
}

