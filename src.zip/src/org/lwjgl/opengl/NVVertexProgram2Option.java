/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class NVVertexProgram2Option {
    public static final int GL_MAX_PROGRAM_EXEC_INSTRUCTIONS_NV = 35060;
    public static final int GL_MAX_PROGRAM_CALL_DEPTH_NV = 35061;

    private NVVertexProgram2Option() {
    }
}

