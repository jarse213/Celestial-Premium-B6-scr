/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class NVMultisampleCoverage {
    public static final int GL_COVERAGE_SAMPLES_NV = 32937;
    public static final int GL_COLOR_SAMPLES_NV = 36384;

    private NVMultisampleCoverage() {
    }
}

