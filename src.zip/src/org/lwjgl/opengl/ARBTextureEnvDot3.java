/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ARBTextureEnvDot3 {
    public static final int GL_DOT3_RGB_ARB = 34478;
    public static final int GL_DOT3_RGBA_ARB = 34479;

    private ARBTextureEnvDot3() {
    }
}

