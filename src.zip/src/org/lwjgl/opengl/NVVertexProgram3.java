/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class NVVertexProgram3 {
    public static final int GL_MAX_VERTEX_TEXTURE_IMAGE_UNITS_ARB = 35660;

    private NVVertexProgram3() {
    }
}

