/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ARBDepthBufferFloat {
    public static final int GL_DEPTH_COMPONENT32F = 36012;
    public static final int GL_DEPTH32F_STENCIL8 = 36013;
    public static final int GL_FLOAT_32_UNSIGNED_INT_24_8_REV = 36269;

    private ARBDepthBufferFloat() {
    }
}

