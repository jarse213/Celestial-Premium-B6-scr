/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ARBTextureMirrorClampToEdge {
    public static final int GL_MIRROR_CLAMP_TO_EDGE = 34627;

    private ARBTextureMirrorClampToEdge() {
    }
}

