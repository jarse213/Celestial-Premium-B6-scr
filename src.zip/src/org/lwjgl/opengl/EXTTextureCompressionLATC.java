/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class EXTTextureCompressionLATC {
    public static final int GL_COMPRESSED_LUMINANCE_LATC1_EXT = 35952;
    public static final int GL_COMPRESSED_SIGNED_LUMINANCE_LATC1_EXT = 35953;
    public static final int GL_COMPRESSED_LUMINANCE_ALPHA_LATC2_EXT = 35954;
    public static final int GL_COMPRESSED_SIGNED_LUMINANCE_ALPHA_LATC2_EXT = 35955;

    private EXTTextureCompressionLATC() {
    }
}

