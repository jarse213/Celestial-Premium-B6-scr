/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class AMDDepthClampSeparate {
    public static final int GL_DEPTH_CLAMP_NEAR_AMD = 36894;
    public static final int GL_DEPTH_CLAMP_FAR_AMD = 36895;

    private AMDDepthClampSeparate() {
    }
}

