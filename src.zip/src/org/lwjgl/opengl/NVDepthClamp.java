/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class NVDepthClamp {
    public static final int GL_DEPTH_CLAMP_NV = 34383;

    private NVDepthClamp() {
    }
}

