/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class NVTessellationProgram5 {
    public static final int GL_TESS_CONTROL_PROGRAM_NV = 35102;
    public static final int GL_TESS_EVALUATION_PROGRAM_NV = 35103;
    public static final int GL_TESS_CONTROL_PROGRAM_PARAMETER_BUFFER_NV = 35956;
    public static final int GL_TESS_EVALUATION_PROGRAM_PARAMETER_BUFFER_NV = 35957;
    public static final int GL_MAX_PROGRAM_PATCH_ATTRIBS_NV = 34520;

    private NVTessellationProgram5() {
    }
}

