/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ATITextureCompression3DC {
    public static final int GL_COMPRESSED_LUMINANCE_ALPHA_3DC_ATI = 34871;

    private ATITextureCompression3DC() {
    }
}

