/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ARBShadowAmbient {
    public static final int GL_TEXTURE_COMPARE_FAIL_VALUE_ARB = 32959;

    private ARBShadowAmbient() {
    }
}

