/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ARBSeamlessCubeMap {
    public static final int GL_TEXTURE_CUBE_MAP_SEAMLESS = 34895;

    private ARBSeamlessCubeMap() {
    }
}

