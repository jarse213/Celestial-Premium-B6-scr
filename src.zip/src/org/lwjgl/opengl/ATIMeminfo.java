/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ATIMeminfo {
    public static final int GL_VBO_FREE_MEMORY_ATI = 34811;
    public static final int GL_TEXTURE_FREE_MEMORY_ATI = 34812;
    public static final int GL_RENDERBUFFER_FREE_MEMORY_ATI = 34813;

    private ATIMeminfo() {
    }
}

