/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ARBStencilTexturing {
    public static final int GL_DEPTH_STENCIL_TEXTURE_MODE = 37098;

    private ARBStencilTexturing() {
    }
}

