/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

final class GlobalLock {
    static final Object lock = new Object();

    GlobalLock() {
    }
}

