/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ARBOcclusionQuery2 {
    public static final int GL_ANY_SAMPLES_PASSED = 35887;

    private ARBOcclusionQuery2() {
    }
}

