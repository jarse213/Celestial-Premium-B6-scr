/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class EXTTextureFilterAnisotropic {
    public static final int GL_TEXTURE_MAX_ANISOTROPY_EXT = 34046;
    public static final int GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT = 34047;

    private EXTTextureFilterAnisotropic() {
    }
}

