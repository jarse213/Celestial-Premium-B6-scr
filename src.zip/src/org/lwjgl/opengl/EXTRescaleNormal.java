/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class EXTRescaleNormal {
    public static final int GL_RESCALE_NORMAL_EXT = 32826;

    private EXTRescaleNormal() {
    }
}

