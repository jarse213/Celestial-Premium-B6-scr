/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class ATITextureMirrorOnce {
    public static final int GL_MIRROR_CLAMP_ATI = 34626;
    public static final int GL_MIRROR_CLAMP_TO_EDGE_ATI = 34627;

    private ATITextureMirrorOnce() {
    }
}

