/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl.opengl;

public final class APPLEAuxDepthStencil {
    public static final int GL_AUX_DEPTH_STENCIL_APPLE = 35348;

    private APPLEAuxDepthStencil() {
    }
}

