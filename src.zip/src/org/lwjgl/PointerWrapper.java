/*
 * Decompiled with CFR 0.150.
 */
package org.lwjgl;

public interface PointerWrapper {
    public long getPointer();
}

