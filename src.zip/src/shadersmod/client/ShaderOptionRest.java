/*
 * Decompiled with CFR 0.150.
 */
package shadersmod.client;

import shadersmod.client.ShaderOption;

public class ShaderOptionRest
extends ShaderOption {
    public ShaderOptionRest(String name) {
        super(name, name, null, new String[]{null}, null, null);
    }
}

