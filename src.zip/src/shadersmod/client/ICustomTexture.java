/*
 * Decompiled with CFR 0.150.
 */
package shadersmod.client;

public interface ICustomTexture {
    public int getTextureId();

    public int getTextureUnit();

    public void deleteTexture();
}

